const middleware = {}

middleware['LoginRequired'] = require('..\\middleware\\LoginRequired.js')
middleware['LoginRequired'] = middleware['LoginRequired'].default || middleware['LoginRequired']

export default middleware
