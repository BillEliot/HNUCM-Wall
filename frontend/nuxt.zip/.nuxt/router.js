import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'

const _6e38ba8a = () => interopDefault(import('../pages/About/index.vue' /* webpackChunkName: "pages/About/index" */))
const _7b3e4fcc = () => interopDefault(import('../pages/Admin/index.vue' /* webpackChunkName: "pages/Admin/index" */))
const _5c0bf433 = () => interopDefault(import('../pages/Article/index.vue' /* webpackChunkName: "pages/Article/index" */))
const _31dc49f5 = () => interopDefault(import('../pages/Bank/index.vue' /* webpackChunkName: "pages/Bank/index" */))
const _4d2c97ef = () => interopDefault(import('../pages/Club/index.vue' /* webpackChunkName: "pages/Club/index" */))
const _3ef977b6 = () => interopDefault(import('../pages/Deal/index.vue' /* webpackChunkName: "pages/Deal/index" */))
const _102f50ba = () => interopDefault(import('../pages/Help/index.vue' /* webpackChunkName: "pages/Help/index" */))
const _1323dbca = () => interopDefault(import('../pages/Hot/index.vue' /* webpackChunkName: "pages/Hot/index" */))
const _0f462abb = () => interopDefault(import('../pages/Lecture/index.vue' /* webpackChunkName: "pages/Lecture/index" */))
const _75216366 = () => interopDefault(import('../pages/Login/index.vue' /* webpackChunkName: "pages/Login/index" */))
const _8e66e0e4 = () => interopDefault(import('../pages/Lose/index.vue' /* webpackChunkName: "pages/Lose/index" */))
const _603d00aa = () => interopDefault(import('../pages/Love/index.vue' /* webpackChunkName: "pages/Love/index" */))
const _33776ef4 = () => interopDefault(import('../pages/NewStudent/index.vue' /* webpackChunkName: "pages/NewStudent/index" */))
const _4509aa2c = () => interopDefault(import('../pages/Organization/index.vue' /* webpackChunkName: "pages/Organization/index" */))
const _a14942c8 = () => interopDefault(import('../pages/Register/index.vue' /* webpackChunkName: "pages/Register/index" */))
const _2bc0eca9 = () => interopDefault(import('../pages/Activity/Jingui/index.vue' /* webpackChunkName: "pages/Activity/Jingui/index" */))
const _5a153c41 = () => interopDefault(import('../pages/Article/new.vue' /* webpackChunkName: "pages/Article/new" */))
const _63d1142e = () => interopDefault(import('../pages/Bank/bank.vue' /* webpackChunkName: "pages/Bank/bank" */))
const _84a223ec = () => interopDefault(import('../pages/Bank/result.vue' /* webpackChunkName: "pages/Bank/result" */))
const _952863d6 = () => interopDefault(import('../pages/Bank/search.vue' /* webpackChunkName: "pages/Bank/search" */))
const _3622f190 = () => interopDefault(import('../pages/Bank/statistics.vue' /* webpackChunkName: "pages/Bank/statistics" */))
const _07a3e0b3 = () => interopDefault(import('../pages/Deal/new.vue' /* webpackChunkName: "pages/Deal/new" */))
const _12b7e2f0 = () => interopDefault(import('../pages/Help/new.vue' /* webpackChunkName: "pages/Help/new" */))
const _356af25c = () => interopDefault(import('../pages/Lose/new.vue' /* webpackChunkName: "pages/Lose/new" */))
const _124745b9 = () => interopDefault(import('../pages/Love/new.vue' /* webpackChunkName: "pages/Love/new" */))
const _10539e04 = () => interopDefault(import('../pages/NewStudent/map.vue' /* webpackChunkName: "pages/NewStudent/map" */))
const _776a844c = () => interopDefault(import('../pages/Organization/club.vue' /* webpackChunkName: "pages/Organization/club" */))
const _ae6fcb84 = () => interopDefault(import('../pages/Organization/science.vue' /* webpackChunkName: "pages/Organization/science" */))
const _5f20c6b6 = () => interopDefault(import('../pages/Organization/subunion.vue' /* webpackChunkName: "pages/Organization/subunion" */))
const _32952f22 = () => interopDefault(import('../pages/Organization/troupe.vue' /* webpackChunkName: "pages/Organization/troupe" */))
const _514191a9 = () => interopDefault(import('../pages/Organization/union.vue' /* webpackChunkName: "pages/Organization/union" */))
const _bc504894 = () => interopDefault(import('../pages/Activity/Jingui/sign.vue' /* webpackChunkName: "pages/Activity/Jingui/sign" */))
const _6efbdf5c = () => interopDefault(import('../pages/Activity/Jingui/statistics.vue' /* webpackChunkName: "pages/Activity/Jingui/statistics" */))
const _6509bef4 = () => interopDefault(import('../pages/Activity/Jingui/Detail/_uid.vue' /* webpackChunkName: "pages/Activity/Jingui/Detail/_uid" */))
const _dcb448ea = () => interopDefault(import('../pages/Article/Detail/_id.vue' /* webpackChunkName: "pages/Article/Detail/_id" */))
const _e7780bf8 = () => interopDefault(import('../pages/Article/Edit/_id.vue' /* webpackChunkName: "pages/Article/Edit/_id" */))
const _0e6670c2 = () => interopDefault(import('../pages/Club/detail/_name.vue' /* webpackChunkName: "pages/Club/detail/_name" */))
const _a9469a4e = () => interopDefault(import('../pages/Deal/Detail/_id.vue' /* webpackChunkName: "pages/Deal/Detail/_id" */))
const _7677665c = () => interopDefault(import('../pages/Deal/Edit/_id.vue' /* webpackChunkName: "pages/Deal/Edit/_id" */))
const _1b536f44 = () => interopDefault(import('../pages/Help/detail/_id.vue' /* webpackChunkName: "pages/Help/detail/_id" */))
const _6b507c1d = () => interopDefault(import('../pages/Help/Edit/_id.vue' /* webpackChunkName: "pages/Help/Edit/_id" */))
const _1dcb4e34 = () => interopDefault(import('../pages/Hot/detail/_id.vue' /* webpackChunkName: "pages/Hot/detail/_id" */))
const _47572110 = () => interopDefault(import('../pages/Lose/Detail/_id.vue' /* webpackChunkName: "pages/Lose/Detail/_id" */))
const _3e22dcc9 = () => interopDefault(import('../pages/Lose/Edit/_id.vue' /* webpackChunkName: "pages/Lose/Edit/_id" */))
const _3954bb13 = () => interopDefault(import('../pages/Love/Detail/_id.vue' /* webpackChunkName: "pages/Love/Detail/_id" */))
const _4bb51b8c = () => interopDefault(import('../pages/Love/Edit/_id.vue' /* webpackChunkName: "pages/Love/Edit/_id" */))
const _c8ffcf16 = () => interopDefault(import('../pages/Profile/message/_uid.vue' /* webpackChunkName: "pages/Profile/message/_uid" */))
const _3c90a36d = () => interopDefault(import('../pages/Profile/_uid.vue' /* webpackChunkName: "pages/Profile/_uid" */))
const _04cf402c = () => interopDefault(import('../pages/index.vue' /* webpackChunkName: "pages/index" */))

Vue.use(Router)

if (process.client) {
  if ('scrollRestoration' in window.history) {
    window.history.scrollRestoration = 'manual'

    // reset scrollRestoration to auto when leaving page, allowing page reload
    // and back-navigation from other pages to use the browser to restore the
    // scrolling position.
    window.addEventListener('beforeunload', () => {
      window.history.scrollRestoration = 'auto'
    })

    // Setting scrollRestoration to manual again when returning to this page.
    window.addEventListener('load', () => {
      window.history.scrollRestoration = 'manual'
    })
  }
}
const scrollBehavior = function (to, from, savedPosition) {
  // if the returned position is falsy or an empty object,
  // will retain current scroll position.
  let position = false

  // if no children detected and scrollToTop is not explicitly disabled
  if (
    to.matched.length < 2 &&
    to.matched.every(r => r.components.default.options.scrollToTop !== false)
  ) {
    // scroll to the top of the page
    position = { x: 0, y: 0 }
  } else if (to.matched.some(r => r.components.default.options.scrollToTop)) {
    // if one of the children has scrollToTop option set to true
    position = { x: 0, y: 0 }
  }

  // savedPosition is only available for popstate navigations (back button)
  if (savedPosition) {
    position = savedPosition
  }

  return new Promise((resolve) => {
    // wait for the out transition to complete (if necessary)
    window.$nuxt.$once('triggerScroll', () => {
      // coords will be used if no selector is provided,
      // or if the selector didn't match any element.
      if (to.hash) {
        let hash = to.hash
        // CSS.escape() is not supported with IE and Edge.
        if (typeof window.CSS !== 'undefined' && typeof window.CSS.escape !== 'undefined') {
          hash = '#' + window.CSS.escape(hash.substr(1))
        }
        try {
          if (document.querySelector(hash)) {
            // scroll to anchor by returning the selector
            position = { selector: hash }
          }
        } catch (e) {
          console.warn('Failed to save scroll position. Please add CSS.escape() polyfill (https://github.com/mathiasbynens/CSS.escape).')
        }
      }
      resolve(position)
    })
  })
}

export function createRouter() {
  return new Router({
    mode: 'history',
    base: decodeURI('/'),
    linkActiveClass: 'nuxt-link-active',
    linkExactActiveClass: 'nuxt-link-exact-active',
    scrollBehavior,

    routes: [{
      path: "/About",
      component: _6e38ba8a,
      name: "About"
    }, {
      path: "/Admin",
      component: _7b3e4fcc,
      name: "Admin"
    }, {
      path: "/Article",
      component: _5c0bf433,
      name: "Article"
    }, {
      path: "/Bank",
      component: _31dc49f5,
      name: "Bank"
    }, {
      path: "/Club",
      component: _4d2c97ef,
      name: "Club"
    }, {
      path: "/Deal",
      component: _3ef977b6,
      name: "Deal"
    }, {
      path: "/Help",
      component: _102f50ba,
      name: "Help"
    }, {
      path: "/Hot",
      component: _1323dbca,
      name: "Hot"
    }, {
      path: "/Lecture",
      component: _0f462abb,
      name: "Lecture"
    }, {
      path: "/Login",
      component: _75216366,
      name: "Login"
    }, {
      path: "/Lose",
      component: _8e66e0e4,
      name: "Lose"
    }, {
      path: "/Love",
      component: _603d00aa,
      name: "Love"
    }, {
      path: "/NewStudent",
      component: _33776ef4,
      name: "NewStudent"
    }, {
      path: "/Organization",
      component: _4509aa2c,
      name: "Organization"
    }, {
      path: "/Register",
      component: _a14942c8,
      name: "Register"
    }, {
      path: "/Activity/Jingui",
      component: _2bc0eca9,
      name: "Activity-Jingui"
    }, {
      path: "/Article/new",
      component: _5a153c41,
      name: "Article-new"
    }, {
      path: "/Bank/bank",
      component: _63d1142e,
      name: "Bank-bank"
    }, {
      path: "/Bank/result",
      component: _84a223ec,
      name: "Bank-result"
    }, {
      path: "/Bank/search",
      component: _952863d6,
      name: "Bank-search"
    }, {
      path: "/Bank/statistics",
      component: _3622f190,
      name: "Bank-statistics"
    }, {
      path: "/Deal/new",
      component: _07a3e0b3,
      name: "Deal-new"
    }, {
      path: "/Help/new",
      component: _12b7e2f0,
      name: "Help-new"
    }, {
      path: "/Lose/new",
      component: _356af25c,
      name: "Lose-new"
    }, {
      path: "/Love/new",
      component: _124745b9,
      name: "Love-new"
    }, {
      path: "/NewStudent/map",
      component: _10539e04,
      name: "NewStudent-map"
    }, {
      path: "/Organization/club",
      component: _776a844c,
      name: "Organization-club"
    }, {
      path: "/Organization/science",
      component: _ae6fcb84,
      name: "Organization-science"
    }, {
      path: "/Organization/subunion",
      component: _5f20c6b6,
      name: "Organization-subunion"
    }, {
      path: "/Organization/troupe",
      component: _32952f22,
      name: "Organization-troupe"
    }, {
      path: "/Organization/union",
      component: _514191a9,
      name: "Organization-union"
    }, {
      path: "/Activity/Jingui/sign",
      component: _bc504894,
      name: "Activity-Jingui-sign"
    }, {
      path: "/Activity/Jingui/statistics",
      component: _6efbdf5c,
      name: "Activity-Jingui-statistics"
    }, {
      path: "/Activity/Jingui/Detail/:uid?",
      component: _6509bef4,
      name: "Activity-Jingui-Detail-uid"
    }, {
      path: "/Article/Detail/:id?",
      component: _dcb448ea,
      name: "Article-Detail-id"
    }, {
      path: "/Article/Edit/:id?",
      component: _e7780bf8,
      name: "Article-Edit-id"
    }, {
      path: "/Club/detail/:name?",
      component: _0e6670c2,
      name: "Club-detail-name"
    }, {
      path: "/Deal/Detail/:id?",
      component: _a9469a4e,
      name: "Deal-Detail-id"
    }, {
      path: "/Deal/Edit/:id?",
      component: _7677665c,
      name: "Deal-Edit-id"
    }, {
      path: "/Help/detail/:id?",
      component: _1b536f44,
      name: "Help-detail-id"
    }, {
      path: "/Help/Edit/:id?",
      component: _6b507c1d,
      name: "Help-Edit-id"
    }, {
      path: "/Hot/detail/:id?",
      component: _1dcb4e34,
      name: "Hot-detail-id"
    }, {
      path: "/Lose/Detail/:id?",
      component: _47572110,
      name: "Lose-Detail-id"
    }, {
      path: "/Lose/Edit/:id?",
      component: _3e22dcc9,
      name: "Lose-Edit-id"
    }, {
      path: "/Love/Detail/:id?",
      component: _3954bb13,
      name: "Love-Detail-id"
    }, {
      path: "/Love/Edit/:id?",
      component: _4bb51b8c,
      name: "Love-Edit-id"
    }, {
      path: "/Profile/message/:uid?",
      component: _c8ffcf16,
      name: "Profile-message-uid"
    }, {
      path: "/Profile/:uid?",
      component: _3c90a36d,
      name: "Profile-uid"
    }, {
      path: "/",
      component: _04cf402c,
      name: "index"
    }],

    fallback: false
  })
}
