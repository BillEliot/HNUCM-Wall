import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from '@nuxt/ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _1cdc90b6 = () => interopDefault(import('..\\pages\\About\\index.vue' /* webpackChunkName: "pages/About/index" */))
const _4f7b9531 = () => interopDefault(import('..\\pages\\Acupuncture\\index.vue' /* webpackChunkName: "pages/Acupuncture/index" */))
const _f5826aba = () => interopDefault(import('..\\pages\\Admin\\index.vue' /* webpackChunkName: "pages/Admin/index" */))
const _4939489c = () => interopDefault(import('..\\pages\\Article\\index.vue' /* webpackChunkName: "pages/Article/index" */))
const _e5561074 = () => interopDefault(import('..\\pages\\Bank\\index.vue' /* webpackChunkName: "pages/Bank/index" */))
const _47e32de8 = () => interopDefault(import('..\\pages\\Club\\index.vue' /* webpackChunkName: "pages/Club/index" */))
const _98e578d4 = () => interopDefault(import('..\\pages\\Deal\\index.vue' /* webpackChunkName: "pages/Deal/index" */))
const _0efdfef4 = () => interopDefault(import('..\\pages\\File\\index.vue' /* webpackChunkName: "pages/File/index" */))
const _7962c9a1 = () => interopDefault(import('..\\pages\\Help\\index.vue' /* webpackChunkName: "pages/Help/index" */))
const _67e06e36 = () => interopDefault(import('..\\pages\\Hot\\index.vue' /* webpackChunkName: "pages/Hot/index" */))
const _057439d8 = () => interopDefault(import('..\\pages\\Lecture\\index.vue' /* webpackChunkName: "pages/Lecture/index" */))
const _7083ab6e = () => interopDefault(import('..\\pages\\Login\\index.vue' /* webpackChunkName: "pages/Login/index" */))
const _37253566 = () => interopDefault(import('..\\pages\\Lose\\index.vue' /* webpackChunkName: "pages/Lose/index" */))
const _a0130e60 = () => interopDefault(import('..\\pages\\Love\\index.vue' /* webpackChunkName: "pages/Love/index" */))
const _72576e6d = () => interopDefault(import('..\\pages\\Match\\index.vue' /* webpackChunkName: "pages/Match/index" */))
const _22fd5df0 = () => interopDefault(import('..\\pages\\Medicine\\index.vue' /* webpackChunkName: "pages/Medicine/index" */))
const _98387bb2 = () => interopDefault(import('..\\pages\\NewStudent\\index.vue' /* webpackChunkName: "pages/NewStudent/index" */))
const _59e6c86f = () => interopDefault(import('..\\pages\\Organization\\index.vue' /* webpackChunkName: "pages/Organization/index" */))
const _794ae9b0 = () => interopDefault(import('..\\pages\\Prescription\\index.vue' /* webpackChunkName: "pages/Prescription/index" */))
const _387b4cff = () => interopDefault(import('..\\pages\\Register\\index.vue' /* webpackChunkName: "pages/Register/index" */))
const _06e3b927 = () => interopDefault(import('..\\pages\\Activity\\Jingui\\index.vue' /* webpackChunkName: "pages/Activity/Jingui/index" */))
const _4bb5ea59 = () => interopDefault(import('..\\pages\\Acupuncture\\search.vue' /* webpackChunkName: "pages/Acupuncture/search" */))
const _f550b954 = () => interopDefault(import('..\\pages\\Acupuncture\\searchResult.vue' /* webpackChunkName: "pages/Acupuncture/searchResult" */))
const _682e96ea = () => interopDefault(import('..\\pages\\Article\\new.vue' /* webpackChunkName: "pages/Article/new" */))
const _0ad949f8 = () => interopDefault(import('..\\pages\\Bank\\bank.vue' /* webpackChunkName: "pages/Bank/bank" */))
const _ba3c72f6 = () => interopDefault(import('..\\pages\\Bank\\errorBook.vue' /* webpackChunkName: "pages/Bank/errorBook" */))
const _5d680b4e = () => interopDefault(import('..\\pages\\Bank\\result.vue' /* webpackChunkName: "pages/Bank/result" */))
const _6dee4b38 = () => interopDefault(import('..\\pages\\Bank\\search.vue' /* webpackChunkName: "pages/Bank/search" */))
const _3e998342 = () => interopDefault(import('..\\pages\\Bank\\statistics.vue' /* webpackChunkName: "pages/Bank/statistics" */))
const _194def38 = () => interopDefault(import('..\\pages\\Deal\\new.vue' /* webpackChunkName: "pages/Deal/new" */))
const _4f2bced5 = () => interopDefault(import('..\\pages\\Extension\\Survival\\index.vue' /* webpackChunkName: "pages/Extension/Survival/index" */))
const _3742d5a2 = () => interopDefault(import('..\\pages\\Help\\new.vue' /* webpackChunkName: "pages/Help/new" */))
const _21a2ff2d = () => interopDefault(import('..\\pages\\Login\\findpassword.vue' /* webpackChunkName: "pages/Login/findpassword" */))
const _7e742bdb = () => interopDefault(import('..\\pages\\Lose\\new.vue' /* webpackChunkName: "pages/Lose/new" */))
const _3d22441e = () => interopDefault(import('..\\pages\\Love\\new.vue' /* webpackChunkName: "pages/Love/new" */))
const _e530ad3c = () => interopDefault(import('..\\pages\\Medicine\\search.vue' /* webpackChunkName: "pages/Medicine/search" */))
const _1cd8961e = () => interopDefault(import('..\\pages\\NewStudent\\map.vue' /* webpackChunkName: "pages/NewStudent/map" */))
const _cdc1dcae = () => interopDefault(import('..\\pages\\Organization\\club.vue' /* webpackChunkName: "pages/Organization/club" */))
const _0a52987e = () => interopDefault(import('..\\pages\\Organization\\science.vue' /* webpackChunkName: "pages/Organization/science" */))
const _7f9798fc = () => interopDefault(import('..\\pages\\Organization\\subunion.vue' /* webpackChunkName: "pages/Organization/subunion" */))
const _6d7c128c = () => interopDefault(import('..\\pages\\Organization\\troupe.vue' /* webpackChunkName: "pages/Organization/troupe" */))
const _661eafec = () => interopDefault(import('..\\pages\\Organization\\union.vue' /* webpackChunkName: "pages/Organization/union" */))
const _53b5b342 = () => interopDefault(import('..\\pages\\Prescription\\search.vue' /* webpackChunkName: "pages/Prescription/search" */))
const _55ed597f = () => interopDefault(import('..\\pages\\Prescription\\searchResult.vue' /* webpackChunkName: "pages/Prescription/searchResult" */))
const _2d0a8778 = () => interopDefault(import('..\\pages\\Activity\\Jingui\\sign.vue' /* webpackChunkName: "pages/Activity/Jingui/sign" */))
const _2cbb319e = () => interopDefault(import('..\\pages\\Activity\\Jingui\\statistics.vue' /* webpackChunkName: "pages/Activity/Jingui/statistics" */))
const _04ce0b0c = () => interopDefault(import('..\\pages\\VirtualSimulation\\VirtualDiagnosis\\log.vue' /* webpackChunkName: "pages/VirtualSimulation/VirtualDiagnosis/log" */))
const _0bec9206 = () => interopDefault(import('..\\pages\\Activity\\Jingui\\Detail\\_uid.vue' /* webpackChunkName: "pages/Activity/Jingui/Detail/_uid" */))
const _ca8500ec = () => interopDefault(import('..\\pages\\Activity\\Jingui\\Log\\_uid.vue' /* webpackChunkName: "pages/Activity/Jingui/Log/_uid" */))
const _de55945e = () => interopDefault(import('..\\pages\\VirtualSimulation\\VirtualDiagnosis\\detail\\_id.vue' /* webpackChunkName: "pages/VirtualSimulation/VirtualDiagnosis/detail/_id" */))
const _4bf8fc58 = () => interopDefault(import('..\\pages\\Acupuncture\\detail\\_name.vue' /* webpackChunkName: "pages/Acupuncture/detail/_name" */))
const _4b285f33 = () => interopDefault(import('..\\pages\\Article\\Detail\\_id.vue' /* webpackChunkName: "pages/Article/Detail/_id" */))
const _6493c533 = () => interopDefault(import('..\\pages\\Club\\detail\\_name.vue' /* webpackChunkName: "pages/Club/detail/_name" */))
const _2c2292a6 = () => interopDefault(import('..\\pages\\Deal\\Detail\\_id.vue' /* webpackChunkName: "pages/Deal/Detail/_id" */))
const _04ec4878 = () => interopDefault(import('..\\pages\\Help\\Detail\\_id.vue' /* webpackChunkName: "pages/Help/Detail/_id" */))
const _44330cdc = () => interopDefault(import('..\\pages\\Hot\\detail\\_id.vue' /* webpackChunkName: "pages/Hot/detail/_id" */))
const _71067324 = () => interopDefault(import('..\\pages\\Lose\\Detail\\_id.vue' /* webpackChunkName: "pages/Lose/Detail/_id" */))
const _4bf4cf32 = () => interopDefault(import('..\\pages\\Love\\Detail\\_id.vue' /* webpackChunkName: "pages/Love/Detail/_id" */))
const _1c4d2444 = () => interopDefault(import('..\\pages\\Match\\Detail\\_id.vue' /* webpackChunkName: "pages/Match/Detail/_id" */))
const _cee61da2 = () => interopDefault(import('..\\pages\\Medicine\\detail\\_name.vue' /* webpackChunkName: "pages/Medicine/detail/_name" */))
const _e3cbe962 = () => interopDefault(import('..\\pages\\Prescription\\detail\\_name.vue' /* webpackChunkName: "pages/Prescription/detail/_name" */))
const _6b093de2 = () => interopDefault(import('..\\pages\\Profile\\message\\_uid.vue' /* webpackChunkName: "pages/Profile/message/_uid" */))
const _aa230bac = () => interopDefault(import('..\\pages\\Profile\\_uid.vue' /* webpackChunkName: "pages/Profile/_uid" */))
const _39db6dbc = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/About",
    component: _1cdc90b6,
    name: "About"
  }, {
    path: "/Acupuncture",
    component: _4f7b9531,
    name: "Acupuncture"
  }, {
    path: "/Admin",
    component: _f5826aba,
    name: "Admin"
  }, {
    path: "/Article",
    component: _4939489c,
    name: "Article"
  }, {
    path: "/Bank",
    component: _e5561074,
    name: "Bank"
  }, {
    path: "/Club",
    component: _47e32de8,
    name: "Club"
  }, {
    path: "/Deal",
    component: _98e578d4,
    name: "Deal"
  }, {
    path: "/File",
    component: _0efdfef4,
    name: "File"
  }, {
    path: "/Help",
    component: _7962c9a1,
    name: "Help"
  }, {
    path: "/Hot",
    component: _67e06e36,
    name: "Hot"
  }, {
    path: "/Lecture",
    component: _057439d8,
    name: "Lecture"
  }, {
    path: "/Login",
    component: _7083ab6e,
    name: "Login"
  }, {
    path: "/Lose",
    component: _37253566,
    name: "Lose"
  }, {
    path: "/Love",
    component: _a0130e60,
    name: "Love"
  }, {
    path: "/Match",
    component: _72576e6d,
    name: "Match"
  }, {
    path: "/Medicine",
    component: _22fd5df0,
    name: "Medicine"
  }, {
    path: "/NewStudent",
    component: _98387bb2,
    name: "NewStudent"
  }, {
    path: "/Organization",
    component: _59e6c86f,
    name: "Organization"
  }, {
    path: "/Prescription",
    component: _794ae9b0,
    name: "Prescription"
  }, {
    path: "/Register",
    component: _387b4cff,
    name: "Register"
  }, {
    path: "/Activity/Jingui",
    component: _06e3b927,
    name: "Activity-Jingui"
  }, {
    path: "/Acupuncture/search",
    component: _4bb5ea59,
    name: "Acupuncture-search"
  }, {
    path: "/Acupuncture/searchResult",
    component: _f550b954,
    name: "Acupuncture-searchResult"
  }, {
    path: "/Article/new",
    component: _682e96ea,
    name: "Article-new"
  }, {
    path: "/Bank/bank",
    component: _0ad949f8,
    name: "Bank-bank"
  }, {
    path: "/Bank/errorBook",
    component: _ba3c72f6,
    name: "Bank-errorBook"
  }, {
    path: "/Bank/result",
    component: _5d680b4e,
    name: "Bank-result"
  }, {
    path: "/Bank/search",
    component: _6dee4b38,
    name: "Bank-search"
  }, {
    path: "/Bank/statistics",
    component: _3e998342,
    name: "Bank-statistics"
  }, {
    path: "/Deal/new",
    component: _194def38,
    name: "Deal-new"
  }, {
    path: "/Extension/Survival",
    component: _4f2bced5,
    name: "Extension-Survival"
  }, {
    path: "/Help/new",
    component: _3742d5a2,
    name: "Help-new"
  }, {
    path: "/Login/findpassword",
    component: _21a2ff2d,
    name: "Login-findpassword"
  }, {
    path: "/Lose/new",
    component: _7e742bdb,
    name: "Lose-new"
  }, {
    path: "/Love/new",
    component: _3d22441e,
    name: "Love-new"
  }, {
    path: "/Medicine/search",
    component: _e530ad3c,
    name: "Medicine-search"
  }, {
    path: "/NewStudent/map",
    component: _1cd8961e,
    name: "NewStudent-map"
  }, {
    path: "/Organization/club",
    component: _cdc1dcae,
    name: "Organization-club"
  }, {
    path: "/Organization/science",
    component: _0a52987e,
    name: "Organization-science"
  }, {
    path: "/Organization/subunion",
    component: _7f9798fc,
    name: "Organization-subunion"
  }, {
    path: "/Organization/troupe",
    component: _6d7c128c,
    name: "Organization-troupe"
  }, {
    path: "/Organization/union",
    component: _661eafec,
    name: "Organization-union"
  }, {
    path: "/Prescription/search",
    component: _53b5b342,
    name: "Prescription-search"
  }, {
    path: "/Prescription/searchResult",
    component: _55ed597f,
    name: "Prescription-searchResult"
  }, {
    path: "/Activity/Jingui/sign",
    component: _2d0a8778,
    name: "Activity-Jingui-sign"
  }, {
    path: "/Activity/Jingui/statistics",
    component: _2cbb319e,
    name: "Activity-Jingui-statistics"
  }, {
    path: "/VirtualSimulation/VirtualDiagnosis/log",
    component: _04ce0b0c,
    name: "VirtualSimulation-VirtualDiagnosis-log"
  }, {
    path: "/Activity/Jingui/Detail/:uid?",
    component: _0bec9206,
    name: "Activity-Jingui-Detail-uid"
  }, {
    path: "/Activity/Jingui/Log/:uid?",
    component: _ca8500ec,
    name: "Activity-Jingui-Log-uid"
  }, {
    path: "/VirtualSimulation/VirtualDiagnosis/detail/:id?",
    component: _de55945e,
    name: "VirtualSimulation-VirtualDiagnosis-detail-id"
  }, {
    path: "/Acupuncture/detail/:name?",
    component: _4bf8fc58,
    name: "Acupuncture-detail-name"
  }, {
    path: "/Article/Detail/:id?",
    component: _4b285f33,
    name: "Article-Detail-id"
  }, {
    path: "/Club/detail/:name?",
    component: _6493c533,
    name: "Club-detail-name"
  }, {
    path: "/Deal/Detail/:id?",
    component: _2c2292a6,
    name: "Deal-Detail-id"
  }, {
    path: "/Help/Detail/:id?",
    component: _04ec4878,
    name: "Help-Detail-id"
  }, {
    path: "/Hot/detail/:id?",
    component: _44330cdc,
    name: "Hot-detail-id"
  }, {
    path: "/Lose/Detail/:id?",
    component: _71067324,
    name: "Lose-Detail-id"
  }, {
    path: "/Love/Detail/:id?",
    component: _4bf4cf32,
    name: "Love-Detail-id"
  }, {
    path: "/Match/Detail/:id?",
    component: _1c4d2444,
    name: "Match-Detail-id"
  }, {
    path: "/Medicine/detail/:name?",
    component: _cee61da2,
    name: "Medicine-detail-name"
  }, {
    path: "/Prescription/detail/:name?",
    component: _e3cbe962,
    name: "Prescription-detail-name"
  }, {
    path: "/Profile/message/:uid?",
    component: _6b093de2,
    name: "Profile-message-uid"
  }, {
    path: "/Profile/:uid?",
    component: _aa230bac,
    name: "Profile-uid"
  }, {
    path: "/",
    component: _39db6dbc,
    name: "index"
  }],

  fallback: false
}

function decodeObj(obj) {
  for (const key in obj) {
    if (typeof obj[key] === 'string') {
      obj[key] = decode(obj[key])
    }
  }
}

export function createRouter () {
  const router = new Router(routerOptions)

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    const r = resolve(to, current, append)
    if (r && r.resolved && r.resolved.query) {
      decodeObj(r.resolved.query)
    }
    return r
  }

  return router
}
