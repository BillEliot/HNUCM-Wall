import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _1cdc90b6 = () => interopDefault(import('..\\pages\\About\\index.vue' /* webpackChunkName: "pages_About_index" */))
const _f5826aba = () => interopDefault(import('..\\pages\\Admin\\index.vue' /* webpackChunkName: "pages_Admin_index" */))
const _4939489c = () => interopDefault(import('..\\pages\\Article\\index.vue' /* webpackChunkName: "pages_Article_index" */))
const _e5561074 = () => interopDefault(import('..\\pages\\Bank\\index.vue' /* webpackChunkName: "pages_Bank_index" */))
const _47e32de8 = () => interopDefault(import('..\\pages\\Club\\index.vue' /* webpackChunkName: "pages_Club_index" */))
const _98e578d4 = () => interopDefault(import('..\\pages\\Deal\\index.vue' /* webpackChunkName: "pages_Deal_index" */))
const _7962c9a1 = () => interopDefault(import('..\\pages\\Help\\index.vue' /* webpackChunkName: "pages_Help_index" */))
const _67e06e36 = () => interopDefault(import('..\\pages\\Hot\\index.vue' /* webpackChunkName: "pages_Hot_index" */))
const _057439d8 = () => interopDefault(import('..\\pages\\Lecture\\index.vue' /* webpackChunkName: "pages_Lecture_index" */))
const _7083ab6e = () => interopDefault(import('..\\pages\\Login\\index.vue' /* webpackChunkName: "pages_Login_index" */))
const _37253566 = () => interopDefault(import('..\\pages\\Lose\\index.vue' /* webpackChunkName: "pages_Lose_index" */))
const _a0130e60 = () => interopDefault(import('..\\pages\\Love\\index.vue' /* webpackChunkName: "pages_Love_index" */))
const _98387bb2 = () => interopDefault(import('..\\pages\\NewStudent\\index.vue' /* webpackChunkName: "pages_NewStudent_index" */))
const _59e6c86f = () => interopDefault(import('..\\pages\\Organization\\index.vue' /* webpackChunkName: "pages_Organization_index" */))
const _387b4cff = () => interopDefault(import('..\\pages\\Register\\index.vue' /* webpackChunkName: "pages_Register_index" */))
const _682e96ea = () => interopDefault(import('..\\pages\\Article\\new.vue' /* webpackChunkName: "pages_Article_new" */))
const _0ad949f8 = () => interopDefault(import('..\\pages\\Bank\\bank.vue' /* webpackChunkName: "pages_Bank_bank" */))
const _5d680b4e = () => interopDefault(import('..\\pages\\Bank\\result.vue' /* webpackChunkName: "pages_Bank_result" */))
const _3e998342 = () => interopDefault(import('..\\pages\\Bank\\statistics.vue' /* webpackChunkName: "pages_Bank_statistics" */))
const _194def38 = () => interopDefault(import('..\\pages\\Deal\\new.vue' /* webpackChunkName: "pages_Deal_new" */))
const _3742d5a2 = () => interopDefault(import('..\\pages\\Help\\new.vue' /* webpackChunkName: "pages_Help_new" */))
const _7e742bdb = () => interopDefault(import('..\\pages\\Lose\\new.vue' /* webpackChunkName: "pages_Lose_new" */))
const _3d22441e = () => interopDefault(import('..\\pages\\Love\\new.vue' /* webpackChunkName: "pages_Love_new" */))
const _1cd8961e = () => interopDefault(import('..\\pages\\NewStudent\\map.vue' /* webpackChunkName: "pages_NewStudent_map" */))
const _cdc1dcae = () => interopDefault(import('..\\pages\\Organization\\club.vue' /* webpackChunkName: "pages_Organization_club" */))
const _0a52987e = () => interopDefault(import('..\\pages\\Organization\\science.vue' /* webpackChunkName: "pages_Organization_science" */))
const _7f9798fc = () => interopDefault(import('..\\pages\\Organization\\subunion.vue' /* webpackChunkName: "pages_Organization_subunion" */))
const _6d7c128c = () => interopDefault(import('..\\pages\\Organization\\troupe.vue' /* webpackChunkName: "pages_Organization_troupe" */))
const _661eafec = () => interopDefault(import('..\\pages\\Organization\\union.vue' /* webpackChunkName: "pages_Organization_union" */))
const _4b285f33 = () => interopDefault(import('..\\pages\\Article\\Detail\\_id.vue' /* webpackChunkName: "pages_Article_Detail__id" */))
const _6493c533 = () => interopDefault(import('..\\pages\\Club\\detail\\_name.vue' /* webpackChunkName: "pages_Club_detail__name" */))
const _2c2292a6 = () => interopDefault(import('..\\pages\\Deal\\Detail\\_id.vue' /* webpackChunkName: "pages_Deal_Detail__id" */))
const _40599098 = () => interopDefault(import('..\\pages\\Help\\detail\\_id.vue' /* webpackChunkName: "pages_Help_detail__id" */))
const _44330cdc = () => interopDefault(import('..\\pages\\Hot\\detail\\_id.vue' /* webpackChunkName: "pages_Hot_detail__id" */))
const _71067324 = () => interopDefault(import('..\\pages\\Lose\\Detail\\_id.vue' /* webpackChunkName: "pages_Lose_Detail__id" */))
const _4bf4cf32 = () => interopDefault(import('..\\pages\\Love\\Detail\\_id.vue' /* webpackChunkName: "pages_Love_Detail__id" */))
const _6b093de2 = () => interopDefault(import('..\\pages\\Profile\\message\\_uid.vue' /* webpackChunkName: "pages_Profile_message__uid" */))
const _aa230bac = () => interopDefault(import('..\\pages\\Profile\\_uid.vue' /* webpackChunkName: "pages_Profile__uid" */))
const _39db6dbc = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages_index" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/About",
    component: _1cdc90b6,
    name: "About"
  }, {
    path: "/Admin",
    component: _f5826aba,
    name: "Admin"
  }, {
    path: "/Article",
    component: _4939489c,
    name: "Article"
  }, {
    path: "/Bank",
    component: _e5561074,
    name: "Bank"
  }, {
    path: "/Club",
    component: _47e32de8,
    name: "Club"
  }, {
    path: "/Deal",
    component: _98e578d4,
    name: "Deal"
  }, {
    path: "/Help",
    component: _7962c9a1,
    name: "Help"
  }, {
    path: "/Hot",
    component: _67e06e36,
    name: "Hot"
  }, {
    path: "/Lecture",
    component: _057439d8,
    name: "Lecture"
  }, {
    path: "/Login",
    component: _7083ab6e,
    name: "Login"
  }, {
    path: "/Lose",
    component: _37253566,
    name: "Lose"
  }, {
    path: "/Love",
    component: _a0130e60,
    name: "Love"
  }, {
    path: "/NewStudent",
    component: _98387bb2,
    name: "NewStudent"
  }, {
    path: "/Organization",
    component: _59e6c86f,
    name: "Organization"
  }, {
    path: "/Register",
    component: _387b4cff,
    name: "Register"
  }, {
    path: "/Article/new",
    component: _682e96ea,
    name: "Article-new"
  }, {
    path: "/Bank/bank",
    component: _0ad949f8,
    name: "Bank-bank"
  }, {
    path: "/Bank/result",
    component: _5d680b4e,
    name: "Bank-result"
  }, {
    path: "/Bank/statistics",
    component: _3e998342,
    name: "Bank-statistics"
  }, {
    path: "/Deal/new",
    component: _194def38,
    name: "Deal-new"
  }, {
    path: "/Help/new",
    component: _3742d5a2,
    name: "Help-new"
  }, {
    path: "/Lose/new",
    component: _7e742bdb,
    name: "Lose-new"
  }, {
    path: "/Love/new",
    component: _3d22441e,
    name: "Love-new"
  }, {
    path: "/NewStudent/map",
    component: _1cd8961e,
    name: "NewStudent-map"
  }, {
    path: "/Organization/club",
    component: _cdc1dcae,
    name: "Organization-club"
  }, {
    path: "/Organization/science",
    component: _0a52987e,
    name: "Organization-science"
  }, {
    path: "/Organization/subunion",
    component: _7f9798fc,
    name: "Organization-subunion"
  }, {
    path: "/Organization/troupe",
    component: _6d7c128c,
    name: "Organization-troupe"
  }, {
    path: "/Organization/union",
    component: _661eafec,
    name: "Organization-union"
  }, {
    path: "/Article/Detail/:id?",
    component: _4b285f33,
    name: "Article-Detail-id"
  }, {
    path: "/Club/detail/:name?",
    component: _6493c533,
    name: "Club-detail-name"
  }, {
    path: "/Deal/Detail/:id?",
    component: _2c2292a6,
    name: "Deal-Detail-id"
  }, {
    path: "/Help/detail/:id?",
    component: _40599098,
    name: "Help-detail-id"
  }, {
    path: "/Hot/detail/:id?",
    component: _44330cdc,
    name: "Hot-detail-id"
  }, {
    path: "/Lose/Detail/:id?",
    component: _71067324,
    name: "Lose-Detail-id"
  }, {
    path: "/Love/Detail/:id?",
    component: _4bf4cf32,
    name: "Love-Detail-id"
  }, {
    path: "/Profile/message/:uid?",
    component: _6b093de2,
    name: "Profile-message-uid"
  }, {
    path: "/Profile/:uid?",
    component: _aa230bac,
    name: "Profile-uid"
  }, {
    path: "/",
    component: _39db6dbc,
    name: "index"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
